import json
from pathlib import Path
import argparse
import re
from pathlib import WindowsPath
'''本节只解决训练集的问题，对于测试集是没有mask的，所以单独列出来,而且尽量只解决MR的，CT的后面也单独列出来'''

#这里对文件夹有要求，里面不得有子目录,比如directory_path这一级里只有两个子目录，输出的结果就是一个空列表[]
def list_files(directory_path):
    try:
        path = Path(directory_path)
        files = [file for file in path.iterdir() if file.is_file()]
        return files
    except Exception as e:
        print(f'读取目录时出错: {e}')
        return []

#只收集子目录
def list_subdir(dir_path):
    try:
        path = Path(dir_path)
        sub_dir = [sub_dir for sub_dir in path.iterdir() if sub_dir.is_dir()]
        return sub_dir
    except Exception as e:
        print(f'读取目录时出错: {e}')
        return []

#这里后面代码需要有映射处理
def label_inf():
    lab_inf = {
        '0':'background',
        '1':'liver',
        '2':'other'
    }
    return lab_inf

def other_inf():
    other_information = {
        'name':'Liver segmentation in Budd-Chiari syndrome',
        'description':'There is no description yet',
        'auther':'Han DongQi'
    }
    return other_information

def create_json(output_dict,json_path):
    with open(json_path, 'w') as json_file:
        json.dump(output_dict, json_file, indent=4)
    print(f"JSON文件已创建: {json_path}")

def extract_number(filename,dataset):
    if dataset == 0:
        match = re.search(r'\d+', filename)
        return match.group(0) if match else None
    elif dataset == 1:
        match = re.match(r'IMG-(\d+)-(\d+)', filename)
        return match.group(1) + match.group(2) if match else None

def find_matching_pairs(img_dir, mask_dir,dataset):
    img_files = list_files(img_dir)
    mask_files = list_files(mask_dir)
    matching_pairs = []

    mask_dict = {extract_number(mask_file.stem,dataset): mask_file for mask_file in mask_files}
    #mask_dict:{003000039: WindowsPath('F:/HanDongqi/Common_data/CHAOS/CHAOS_Train_Sets/Train_Sets/MR/32/T2SPIR/Ground/IMG-0030-00039.png')}
    for img_file in img_files:
        img_number = extract_number(img_file.stem,dataset)
        mask_file = mask_dict.get(img_number)
        if mask_file:
            img_file_norm = img_file.as_posix()
            mask_file_norm = mask_file.as_posix()
            matching_pairs.append({'image': img_file_norm, 'mask': mask_file_norm})
        else:
            print(f'警告: 没有找到与 {img_file} 匹配的标签文件')

    return matching_pairs

def find_matching_pairs2(img_dir, mask_dir,dataset):
    img_files = list_files(img_dir)
    mask_files = list_files(mask_dir)
    matching_pairs = []

    # 创建 mask 字典
    mask_dict = {int(extract_number(mask_file.stem, dataset)): mask_file for mask_file in mask_files}

    for img_file in img_files:
        # 提取编号并转换为整数后加 1
        img_number = int(extract_number(img_file.stem, dataset)) + 1

        # 从字典中查找匹配的 mask 文件
        mask_file = mask_dict.get(img_number)
        if mask_file:
            img_file_norm = img_file.as_posix()
            mask_file_norm = mask_file.as_posix()
            matching_pairs.append({'image': img_file_norm, 'mask': mask_file_norm})
        else:
            print(f'警告: 没有找到与 {img_file} 匹配的标签文件')

    return matching_pairs

'''上面几个函数基本上不需要修改，直接调用即可'''



def DUKE_LIVER_switch():
    path_t = Path(args.DUKE_LIVER_dir_t)
    path_test = Path(args.DUKE_LIVER_dir_test)
    sub_t = list_subdir(path_t)
    sub_test = list_subdir(path_test)
    #[WindowsPath('F:/HanDongqi/Common_data/DUKE_LIVER/Segmentation/Segmentation/0001'),...]
    train_data = []
    tets_data = []
    for sub in sub_t:
        sub_2 = list_subdir(Path(sub))
        #[WindowsPath('F:/HanDongqi/Common_data/DUKE_LIVER/Segmentation/Segmentation/0001/16'),...]
        for sub_3 in sub_2:
            path_img = Path(sub_3) / 'images'
            path_mask = Path(sub_3) / 'masks'
            pairs = find_matching_pairs(path_img, path_mask, 0)
            train_data.extend(pairs)


    for sub in sub_test:
        sub_2 = list_subdir(Path(sub))
        #[WindowsPath('F:/HanDongqi/Common_data/DUKE_LIVER/Segmentation/Segmentation/0001/16'),...]
        for sub_3 in sub_2:
            path_img = Path(sub_3) / 'images'
            path_mask = Path(sub_3) / 'masks'
            pairs = find_matching_pairs(path_img, path_mask, 0)
            tets_data.extend(pairs)

    return train_data,tets_data

def DUKE_LIVER_json():
    json_path =  args.DUKE_LIVER_json
    other_information = other_inf()
    lab_inf = label_inf()
    train_data,tets_data = DUKE_LIVER_switch()
    output_dict = {'information': other_information, 'label': lab_inf, 'training': train_data,'testing':tets_data}
    create_json(output_dict, json_path)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()

    # DUKE_LIVER数据库文件路径，只修改此处即可，倘若需要变化训练测试集，见DUKE_LIVER_switch（）函数
    parser.add_argument('--DUKE_LIVER_dir_t', type=str,default='F:/HanDongqi/Common_data/duke/training', help='DUKE_LIVER_dir')
    parser.add_argument('--DUKE_LIVER_dir_test', type=str, default='F:/HanDongqi/Common_data/duke/testing',help='DUKE_LIVER_dir')
    parser.add_argument('--DUKE_LIVER_json', type=str, default='F:/HanDongqi/json/duke.json',help='json')

    args = parser.parse_args()

    #调用

    DUKE_LIVER_json()

