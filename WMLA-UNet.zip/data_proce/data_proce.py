import numpy as np
from torch.utils.data import DataLoader,random_split
from monai.data import  load_decathlon_datalist,Dataset,CacheDataset,SmartCacheDataset
from monai.transforms import (
    EnsureChannelFirstd,
    Compose,
    LoadImaged,
    ScaleIntensityd,
    SplitDimd,
    Resized,
    Lambda,

    RandFlipd,RandRotate90d,RandCropByPosNegLabeld,RandShiftIntensityd,ToTensord,EnsureTyped,RandSpatialCropd, Rand2DElasticd
)



def duke_map_labels(mask):
    # 生成与标签图像大小匹配的单通道标签（0代表背景，1代表Liver）
    mapped_mask = np.zeros_like(mask, dtype=np.float32)  # 创建相同形状的空数组
    mapped_mask[mask == 1] = 1.0  # Liver（前景）
    return mapped_mask

def duke_transform_mask(data):
    return {"image": data["image"], "mask": duke_map_labels(data["mask"])}

class SliceDataset(Dataset):
    def __init__(self, data, transform=None):
        self.data = data
        self.transform = transform

        # 将每个样本的切片进一步拆分，并将其存储在一个列表中
        self.slices = []
        for i in range(len(self.data)):
            x = self.data[i]
            self.slices.extend(x)

    def __len__(self):
        return len(self.slices)  # 返回切片的数量

    def __getitem__(self, idx):
        # 返回一个包含图像和mask的字典
        sample = self.slices[idx]

        if self.transform:
            sample = self.transform(sample)  # 确保传递给transform的仍是字典
        return sample  # 返回包含 'image' 和 'mask' 的字典


class Dateset_loader:
    def __init__(self,args):
        self.image_size = args.image_size
        self.cache_num = args.cache_num
        self.roi_size = args.roi_size



    def duke_load(self,json_path):
        files = load_decathlon_datalist(json_path, True, "training")
        transforms_3to2 = Compose(
            [
                LoadImaged(keys=["image", "mask"]),
                ScaleIntensityd(keys="image"),
                SplitDimd(keys=["image", "mask"], dim=-1, output_postfixes=None, keepdim=False, list_output=True)
            ]
        )

        train_ds = SmartCacheDataset(data=files, transform=transforms_3to2, replace_rate=0.8, cache_num=self.cache_num,shuffle=False)

        transforms = Compose(
            [
                EnsureChannelFirstd(keys=["image", "mask"]),  # 这边需要先加入通道，否则下面的变换会出乱
                Lambda(func=duke_transform_mask),
                Resized(keys=["image", "mask"], spatial_size=self.image_size),

                #进行数据增强
                RandFlipd(keys=["image", "mask"], spatial_axis=0, prob=0.5),  # 随机左右翻转
                RandFlipd(keys=["image", "mask"], spatial_axis=1, prob=0.5),  # 随机上下翻转
                RandRotate90d(keys=["image", "mask"], prob=0.5, max_k=3),  # 随机90度旋转
                RandShiftIntensityd(keys="image", offsets=0.1, prob=0.5),  # 图像亮度随机偏移
                RandSpatialCropd(keys=["image", "mask"], roi_size=self.roi_size, random_size=False),#按指定大小随机裁剪
                Rand2DElasticd(
                    keys=["image", "mask"],  # 需要进行形变的键
                    spacing=(20, 20),  # 控制网格间距，值越大变形越明显
                    magnitude_range=(1, 2),  # 控制形变强度范围
                    rotate_range=0.1,  # 允许的随机旋转范围（弧度）
                    shear_range=0.1,  # 随机剪切范围
                    translate_range=(5, 5),  # 随机平移范围
                    scale_range=(0.9, 1.1),  # 随机缩放范围
                    prob=0.5,  # 应用弹性形变的概率
                    mode=("bilinear", "nearest"),  # 图像和掩码的插值方式
                    padding_mode="zeros",  # 变形时的填充方式（默认用零填充）
                    )

            ]
        )

        train_ds2 = SliceDataset(train_ds, transform=transforms)
        return train_ds2


    def duke_load_test(self, json_path):
        files = load_decathlon_datalist(json_path, True, "testing")
        transforms_3to2 = Compose(
            [
                LoadImaged(keys=["image", "mask"]),
                ScaleIntensityd(keys="image"),
                SplitDimd(keys=["image", "mask"], dim=-1, output_postfixes=None, keepdim=False, list_output=True)
            ]
        )
        # 构建训练和验证数据集
        test_ds = CacheDataset(data=files, transform=transforms_3to2)
        transforms = Compose(
            [
                EnsureChannelFirstd(keys=["image", "mask"]),  # 这边需要先加入通道，否则下面的变换会出乱
                Lambda(func=duke_transform_mask),
                Resized(keys=["image", "mask"], spatial_size=self.image_size),
            ]
        )

        test_ds2 = SliceDataset(test_ds, transform=transforms)
        return test_ds2


def common_data_loader(data,args):
    dataset_size = len(data)
    print(dataset_size)
    train_size = int(0.8 * dataset_size)
    val_size = dataset_size - train_size
    # print(val_size)
    train_dataset, val_dataset = random_split(data, [train_size, val_size])
    train_loader = DataLoader(train_dataset,batch_size=args.batch_size,shuffle = False)
    val_loader = DataLoader(val_dataset,batch_size=args.batch_size,shuffle = False)

    return train_loader,val_loader

