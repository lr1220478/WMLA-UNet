import numpy as np
from sklearn.metrics import confusion_matrix, jaccard_score, f1_score
from matplotlib import pyplot as plt
import os
#IoU,DSC, Acc, Spe,Sen

def calculate_metric_percase(pred, gt):
    """
    计算二分类分割任务的各种指标：Dice, IoU, Acc, Specificity, Sensitivity。

    Args:
        pred (numpy.ndarray): 预测的二值图像（0或1）。
        gt (numpy.ndarray): 真实标签的二值图像（0或1）。

    Returns:
        dict: 包含 Dice, IoU, Accuracy, Specificity, Sensitivity 的字典。
    """
    # 确保二值化
    pred[pred > 0] = 1
    gt[gt > 0] = 1

    # 初始化结果字典
    metrics = {}

    if pred.sum() > 0 or gt.sum() > 0:  # 有前景区域
        # Dice (F1 Score) and IoU
        dice = f1_score(gt.flatten(), pred.flatten())
        iou = jaccard_score(gt.flatten(), pred.flatten())

        # 混淆矩阵
        tn, fp, fn, tp = confusion_matrix(gt.flatten(), pred.flatten(), labels=[0, 1]).ravel()

        # Accuracy
        acc = (tp + tn) / (tp + tn + fp + fn)

        # Sensitivity (Recall)
        sen = tp / (tp + fn) if (tp + fn) != 0 else 0

        # Specificity
        spe = tn / (tn + fp) if (tn + fp) != 0 else 0

        # 填充结果并保留小数点后四位
        metrics["dice"] = round(dice, 4)
        metrics["iou"] = round(iou, 4)
        metrics["acc"] = round(acc, 4)
        metrics["sen"] = round(sen, 4)
        metrics["spe"] = round(spe, 4)
    else:  # 若没有前景区域，将所有指标设为 0
        metrics = {k: 0.0 for k in ["dice", "iou", "acc", "sen", "spe"]}

    return metrics


def save_imgs(img, msk, msk_pred, i, save_path, datasets, test_data_name=None):
    # 确保 img 是有效格式
    img = img.squeeze(0).permute(1, 2, 0).detach().cpu().numpy()
    img = img / 255. if img.max() > 1.1 else img

    # 处理 mask 和预测 mask
    if datasets == 'retinal':
        msk = np.squeeze(msk, axis=0) if msk.shape[0] == 1 else msk
        msk_pred = np.squeeze(msk_pred, axis=0) if msk_pred.shape[0] == 1 else msk_pred
    else:
        msk = np.where(np.squeeze(msk, axis=0) > 0.5, 1, 0) if msk.shape[0] == 1 else np.where(msk > 0.5, 1, 0)

        # 更健壮的处理
        if msk_pred.ndim == 3 and msk_pred.shape[0] == 1:
            msk_pred = np.squeeze(msk_pred, axis=0)
        elif msk_pred.ndim == 3 and msk_pred.shape[0] > 1:
            msk_pred = msk_pred[0, :, :]
        elif msk_pred.ndim == 2:
            pass
        else:
            raise ValueError(f"Unexpected msk_pred shape: {msk_pred.shape}")

    # 创建图像
    plt.figure(figsize=(7, 15))
    plt.subplot(3, 1, 1)
    plt.imshow(img)
    plt.axis('off')

    plt.subplot(3, 1, 2)
    plt.imshow(msk, cmap='gray')
    plt.axis('off')

    plt.subplot(3, 1, 3)
    plt.imshow(msk_pred, cmap='gray')
    plt.axis('off')

    # 拼接保存路径
    if test_data_name is not None:
        save_path = os.path.join(save_path, f"{test_data_name}_{i}.png")
    else:
        save_path = os.path.join(save_path, f"{i}.png")

    # 确保保存路径的目录存在（不创建多余目录）
    save_dir = os.path.dirname(save_path)
    if not os.path.isdir(save_dir):
        raise FileNotFoundError(f"Directory does not exist: {save_dir}")

    # 保存图像
    plt.savefig(save_path)
    plt.close()