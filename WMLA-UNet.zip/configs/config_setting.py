class setting_config:
    network = 'mlla'
    model_config = {
        'img_size': 224,
        'patch_size': 4,
        'in_chans': 1,
        'num_classes': 1,
        'embed_dim': 96,
        'depths':[2, 2, 6, 2],
        'num_heads':[3, 6, 12, 24],
        'mlp_ratio': 4.,
        'qkv_bias': True,
        'drop_rate': 0.0,
        'drop_path_rate': 0.1,
        'ape': False,
        'use_checkpoint':False
    }