import torch
import argparse
from configs.config_setting import setting_config
import os
from models.build_mallunetwavelet_CS import MLLA_Unet
from data_proce.data_proce import Dateset_loader
from torch.utils.data import DataLoader
from configs.val import calculate_metric_percase,save_imgs

parser = argparse.ArgumentParser()
parser.add_argument('--duke_liver_path', type=str,default='F:/HanDongqi/json/duke_liver_nii.json', help='common_data,train')
parser.add_argument('--load_state_path', type=str,default='F:/HanDongqi/mymodel/pth/mall_unet_wtconv_CS/mllaunet_wtconv_CS_best_model.pth', help='the pth of training')
parser.add_argument('--output_dir', type=str,default='F:/HanDongqi/mymodel/test_mllaunet_wtconv_CS/duke_liver', help='the size of image saved')

parser.add_argument('--batch_size', type=int,default=1, help='the batch_size')
parser.add_argument('--cache_num', type=int,default=6, help='the number of cache_num in data_proce')
parser.add_argument('--image_size', type=list,default=[224,224], help='data_proce need')
parser.add_argument('--lr', type=float,default=1e-3, help='Learning rate')
parser.add_argument('--base_lr', type=float,  default=0.01,help='segmentation network learning rate')
parser.add_argument('--max_iterations', type=int,default=4000, help='maximum epoch number to train')
parser.add_argument('--exp', type=str,default='duke/Fully_Supervised', help='experiment_name')
parser.add_argument('--model', type=str,default='mambaunet', help='model_name')
parser.add_argument('--num_classes', type=int,  default=1, help='output channel of network')
parser.add_argument('--seed', type=int,  default=1337, help='random seed')
parser.add_argument('--deterministic', type=int,  default=1,help='whether use deterministic training')

args = parser.parse_args()
dataset_loader = Dateset_loader(args)
config = setting_config()

def test_model(test_loader, model, device, output_dir, calculate_metric_percase, save_imgs):
    os.makedirs(output_dir, exist_ok=True)  # 确保保存路径存在

    # 存储整体指标的字典
    overall_metrics = {
        "dice": [],
        "iou": [],
        "acc": [],
        "sen": [],
        "spe": []
    }

    with torch.no_grad():
        for i_batch, sampled_batch in enumerate(test_loader):
            # 获取输入图像和真实标签
            image, mask = sampled_batch['image'].to(device), sampled_batch['mask'].to(device)

            # 模型预测
            outputs = model(image)
            outputs = (torch.sigmoid(outputs) > 0.5).int()

            # 将数据转为 NumPy 格式
            pred = outputs.detach().cpu().numpy()[0, 0]  # 单通道预测
            gt = mask.detach().cpu().numpy()[0, 0]  # 单通道真实值
            img = image.detach().cpu()

            # 计算指标
            metrics = calculate_metric_percase(pred, gt)
            for key, value in metrics.items():
                overall_metrics[key].append(value)

            # 输出指标到控制台
            print(f"Sample {i_batch}: {metrics}")

            # 保存图像
            save_imgs(img, gt, pred, i_batch, output_dir, datasets='medical')

    # 汇总整体指标
    final_metrics = {k: sum(v) / len(v) for k, v in overall_metrics.items()}
    print("\nFinal Metrics:")
    for k, v in final_metrics.items():
        print(f"{k}: {v:.4f}")

    return final_metrics

if __name__ == "__main__":
    # duke_load = dataset_loader.duke_load_test(args.duke_liver_path)
    # test_loader = DataLoader(duke_load, batch_size=args.batch_size, shuffle=False)
    test = dataset_loader.duke_load_test(args.duke_liver_path)
    test_loader = DataLoader(test, batch_size=args.batch_size, shuffle=False)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model = MLLA_Unet(**config.model_config)#修改此处即可
    model = model.cuda()
    model.load_state_dict(torch.load(args.load_state_path))  # 加载训练好的模型
    output_dir = args.output_dir  # 指定存储路径

    final_metrics = test_model(
        test_loader=test_loader,
        model=model,
        device=device,
        output_dir=output_dir,
        calculate_metric_percase=calculate_metric_percase,
        save_imgs=save_imgs
    )

    print("Testing complete. Final metrics saved.")