from data_proce.data_proce import Dateset_loader,common_data_loader
import argparse
import torch
from torch.utils.tensorboard import SummaryWriter
from models.build_mllaunetwavelet import MLLA_Unet
from configs.config_setting import setting_config
import torch.optim as optim
import logging
from tqdm import tqdm
import numpy as np
import os
import torch.backends.cudnn as cudnn
import random
import sys
import monai
from monai.metrics import DiceMetric, MeanIoU, HausdorffDistanceMetric
from torch.nn.modules.loss import BCEWithLogitsLoss
from torch.utils.data import DataLoader

parser = argparse.ArgumentParser()
parser.add_argument('--duke_liver_path', type=str, default='F:/HanDongqi/json/duke.json',help='common_data,train')
parser.add_argument('--SummaryWriter_path', type=str,default='F:/HanDongqi/BCS_EXP/tensorboard/zhou', help='the size of image saved')
parser.add_argument('--snapshot_path', type=str,default='F:/HanDongqi/BCS_EXP/zhou', help='the size of image saved')

parser.add_argument('--batch_size', type=int,default=16, help='the batch_size')
parser.add_argument('--cache_num', type=int, default=60, help='the number of cache_num in data_proce')
parser.add_argument('--image_size', type=list,default=[336,336], help='data_proce need')
parser.add_argument('--roi_size', type=list, default=[224, 224], help='data_proce need')
parser.add_argument('--lr', type=float,default=1e-3, help='Learning rate')
parser.add_argument('--base_lr', type=float,  default=0.01,help='segmentation network learning rate')
parser.add_argument('--max_iterations', type=int,default=16000, help='maximum epoch number to train')
parser.add_argument('--exp', type=str,default='duke/Fully_Supervised', help='experiment_name')
parser.add_argument('--model', type=str,default='mlla_unet', help='model_name')
parser.add_argument('--num_classes', type=int,  default=1, help='output channel of network')
parser.add_argument('--seed', type=int,  default=1337, help='random seed')
parser.add_argument('--deterministic', type=int,  default=1,help='whether use deterministic training')


args = parser.parse_args()
dataset_loader = Dateset_loader(args)
config = setting_config()


def train(args, snapshot_path):
    base_lr = args.base_lr
    max_iterations = args.max_iterations

    duke_load = dataset_loader.duke_load(args.duke_liver_path)
    train_loader, val_loader = common_data_loader(duke_load, args)

    dice_metric = DiceMetric(include_background=True, reduction="mean", get_not_nans=False)
    iou_metric = MeanIoU(include_background=True, reduction="mean")
    hd95_metric = HausdorffDistanceMetric(include_background=True, reduction="mean", percentile=95)

    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    model = MLLA_Unet(**config.model_config).to(device)

    if torch.cuda.device_count() > 1:
        print(f"使用 {torch.cuda.device_count()} 个 GPU 进行训练")
        model = torch.nn.DataParallel(model)

    model.train()

    bce_loss = BCEWithLogitsLoss()
    loss_function = monai.losses.DiceLoss(sigmoid=False)

    optimizer = optim.SGD(model.parameters(), lr=base_lr,
                          momentum=0.9, weight_decay=0.0001)

    writer = SummaryWriter(args.SummaryWriter_path)
    logging.info("{} iterations per epoch".format(len(train_loader)))

    iter_num = 0
    max_epoch = max_iterations // len(train_loader) + 1

    iterator = tqdm(range(max_epoch), ncols=70)
    for epoch_num in iterator:
        for i_batch, sampled_batch in enumerate(train_loader):
            volume_batch, label_batch = sampled_batch['image'], sampled_batch['mask']
            volume_batch, label_batch = volume_batch.to(device), label_batch.to(device)

            outputs = model(volume_batch)#这个outputs是一个tuple
            outputs_soft = torch.sigmoid(outputs)

            loss_bce = bce_loss(outputs, label_batch)
            loss_dice = loss_function(outputs_soft, label_batch)

            loss = 0.5 * (loss_bce + loss_dice)

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            lr_ = base_lr * (1.0 - iter_num / max_iterations) ** 0.9
            for param_group in optimizer.param_groups:
                param_group['lr'] = lr_

            iter_num = iter_num + 1
            writer.add_scalar('info/lr', lr_, iter_num)
            writer.add_scalar('info/total_loss', loss, iter_num)

            logging.info(
                'iteration %d : loss : %f' % (iter_num, loss.item()))

            if iter_num % 20 == 0:
                image = volume_batch[1, 0:1, :, :]
                writer.add_image('train/Image', image, iter_num)

                outputs = (torch.sigmoid(outputs) > 0.5).int()
                writer.add_image('train/Prediction',
                                 outputs[1, ...] * 50, iter_num)
                labs = label_batch[1, ...].unsqueeze(0) * 50
                writer.add_image('train/GroundTruth', labs.squeeze(0), iter_num)

            best_performance = 0.0
            if iter_num > 0 and iter_num % 200 == 0:  # 原本是200
                model.eval()
                dice_metric.reset()
                iou_metric.reset()
                hd95_metric.reset()
                with torch.no_grad():
                    for i_batch, sampled_batch in enumerate(val_loader):
                        val_images, val_labels = sampled_batch['image'].to(device), sampled_batch['mask'].to(device)
                        outputs = model(val_images)
                        outputs = (torch.sigmoid(outputs) > 0.5).int()
                        dice_metric(y_pred=outputs, y=val_labels)
                        iou_metric(y_pred=outputs, y=val_labels)
                        hd95_metric(y_pred=outputs, y=val_labels)

                    performance = dice_metric.aggregate().item()
                    iou_performance = iou_metric.aggregate().item()
                    hd95_performance = hd95_metric.aggregate().item()

                    dice_metric.reset()  # 在计算完成后重置
                    iou_metric.reset()
                    hd95_metric.reset()

                    # 将 Dice 结果写入 TensorBoard
                    writer.add_scalar("Validation/Dice", performance, iter_num)
                    writer.add_scalar("Validation/IoU", iou_performance, iter_num)
                    writer.add_scalar("Validation/HD95", hd95_performance, iter_num)

                if performance > best_performance:
                    best_performance = performance
                    save_mode_path = os.path.join(snapshot_path,
                                                  f'iter_{iter_num}_dice_{round(best_performance, 4)}.pth')
                    save_best = os.path.join(snapshot_path, f'{args.model}_best_model.pth')
                    torch.save(model.state_dict(), save_mode_path)
                    torch.save(model.state_dict(), save_best)

                logging.info(f'iteration {iter_num} : mean_dice : {performance:.4f}')
                model.train()  # 恢复训练模式

            if iter_num % 3000 == 0:
                save_mode_path = os.path.join(
                    snapshot_path, 'iter_' + str(iter_num) + '.pth')
                torch.save(model.state_dict(), save_mode_path)
                logging.info("save model to {}".format(save_mode_path))

            if iter_num >= max_iterations:
                break
        if iter_num >= max_iterations:
            iterator.close()
            break
    writer.close()
    return "Training Finished!"


if __name__ == "__main__":
    if not args.deterministic:
        cudnn.benchmark = True
        cudnn.deterministic = False
    else:
        cudnn.benchmark = False
        cudnn.deterministic = True

    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed(args.seed)

    snapshot_path = args.snapshot_path + "/{}_labeled/{}".format(
        args.exp, args.model)

    if not os.path.exists(snapshot_path):
        os.makedirs(snapshot_path)

    logging.basicConfig(filename=snapshot_path + "/log.txt", level=logging.INFO,
                        format='[%(asctime)s.%(msecs)03d] %(message)s', datefmt='%H:%M:%S')
    logging.getLogger().addHandler(logging.StreamHandler(sys.stdout))
    logging.info(str(args))
    train(args, snapshot_path)

